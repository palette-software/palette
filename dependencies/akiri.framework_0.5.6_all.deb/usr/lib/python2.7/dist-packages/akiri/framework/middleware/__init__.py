# Copyright (c) Akiri Solutions, Inc.  All Rights Reserved.
"""WSGI middleware included with the `akiri.framework`."""
import pkg_resources
pkg_resources.declare_namespace(__name__)
