# Copyright (c) Akiri Solutions, Inc.  All Rights Reserved.
""" Container module. """
import pkg_resources
pkg_resources.declare_namespace(__name__)
