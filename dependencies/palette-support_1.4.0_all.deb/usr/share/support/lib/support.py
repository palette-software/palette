import os
import sys
import ConfigParser as configparser

# global(s)
_verbose = False
_parser = None
_filelist = None

def init(filenames=None, verbose=False):
    global _verbose
    global _parser
    global _filelist

    if not filenames:
        filenames = ['/etc/support.cfg',
                    os.path.expanduser('~/.support'),
                    'support.cfg']
    elif isinstance(filenames, basestring):
        filenames = [filenames]
    _verbose = verbose
    _parser = configparser.SafeConfigParser()
    _filelist = _parser.read(filenames)

def verbose(msg, *args):
    if _verbose:
        if args:
            msg = msg % args
        print msg

def fatal(msg, *args, **kwargs):
    msg = '[ERROR] ' + msg
    if args:
        msg = msg % args
    print >> sys.stderr, msg
    return_code =  'return_code' in kwargs and kwargs['return_code'] or 1
    sys.exit(return_code)

def getint(data, key, default=None):
    try:
        return int(data[key])
    except StandardError:
        return default

def readcfg(section, required=None):
    if required is None:
        required = []

    if not _filelist:
        fatal('No configuration file found.')

    if not _parser.has_section(section):
        fatal("No section '%s' in configuration file(s).", section)

    for option in required:
        if not _parser.has_option(section, option):
            fatal("Option '%s' is missing from configuration.", option)

    data = {}
    for key, value in _parser.items(section):
        data[key] = value
    return data
